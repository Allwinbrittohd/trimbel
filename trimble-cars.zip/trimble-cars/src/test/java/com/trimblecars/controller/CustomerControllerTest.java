package com.trimblecars.controller;

import com.trimblecars.model.*;
import com.trimblecars.service.CustomerService;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CustomerController.class)
public class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private CustomerService customerService;

    @Test
    public void testGetCustomerLeases() throws Exception {
        User dummyUser = new User();
        Car dummyCar = new Car();

        Lease lease1 = Lease.builder()
                .id(1L)
                .customer(dummyUser)
                .car(dummyCar)
                .startDate(LocalDate.now().minusDays(10))
                .endDate(LocalDate.now().minusDays(5))
                .build();

        Lease lease2 = Lease.builder()
                .id(2L)
                .customer(dummyUser)
                .car(dummyCar)
                .startDate(LocalDate.now().minusDays(4))
                .endDate(LocalDate.now().minusDays(1))
                .build();

        when(customerService.getCustomerLeases(1L)).thenReturn(List.of(lease1, lease2));

        mockMvc.perform(get("/customers/1/leases"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetCustomerLeases_Empty() throws Exception {
        when(customerService.getCustomerLeases(2L)).thenReturn(List.of());

        mockMvc.perform(get("/customers/2/leases"))
                .andExpect(status().isOk());
    }
}

package com.trimblecars.service;

import com.trimblecars.model.*;
import com.trimblecars.repository.LeaseRepository;
import com.trimblecars.repository.UserRepository;
import com.trimblecars.repository.CarRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerServiceTest {

    @Mock
    private LeaseRepository leaseRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private CustomerService customerService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetCustomerLeases() {
        User customer = new User();
        customer.setId(1L);

        Car car = new Car();

        Lease lease1 = Lease.builder()
                .id(1L)
                .customer(customer)
                .car(car)
                .startDate(LocalDate.of(2023, 1, 1))
                .endDate(LocalDate.of(2023, 1, 10))
                .build();

        Lease lease2 = Lease.builder()
                .id(2L)
                .customer(customer)
                .car(car)
                .startDate(LocalDate.of(2023, 2, 1))
                .endDate(LocalDate.of(2023, 2, 10))
                .build();

        when(userRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(leaseRepository.findByCustomer(customer)).thenReturn(Arrays.asList(lease1, lease2));

        List<Lease> leases = customerService.getCustomerLeases(1L);
        assertEquals(2, leases.size());
    }

    @Test
    public void testGetCustomerLeases_NoLeases() {
        User customer = new User();
        customer.setId(2L);

        when(userRepository.findById(2L)).thenReturn(Optional.of(customer));
        when(leaseRepository.findByCustomer(customer)).thenReturn(List.of());

        List<Lease> leases = customerService.getCustomerLeases(2L);
        assertEquals(0, leases.size());
    }
}

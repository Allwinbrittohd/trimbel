package com.trimblecars.controller;

import com.trimblecars.model.Car;
import com.trimblecars.model.User;
import com.trimblecars.service.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/owners")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    @PostMapping("/register")
    public User registerOwner(@RequestBody User owner) {
        return ownerService.registerOwner(owner);
    }

    @PostMapping("/{ownerId}/cars")
    public Car addCar(@PathVariable Long ownerId, @RequestBody Car car) {
        return ownerService.addCar(ownerId, car);
    }

    @GetMapping("/{ownerId}/cars")
    public List<Car> getOwnerCars(@PathVariable Long ownerId) {
        return ownerService.getOwnerCars(ownerId);
    }
}

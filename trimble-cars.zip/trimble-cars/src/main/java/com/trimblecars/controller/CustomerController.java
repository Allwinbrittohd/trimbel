package com.trimblecars.controller;

import com.trimblecars.model.Car;
import com.trimblecars.model.Lease;
import com.trimblecars.model.User;
import com.trimblecars.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public User registerCustomer(@RequestBody User customer) {
        return customerService.registerCustomer(customer);
    }

    @GetMapping("/cars")
    public List<Car> getAvailableCars() {
        return customerService.getAvailableCars();
    }

    @PostMapping("/{customerId}/lease/{carId}")
    public Lease startLease(@PathVariable Long customerId, @PathVariable Long carId) {
        return customerService.startLease(customerId, carId);
    }

    @PostMapping("/{customerId}/end-lease/{carId}")
    public Lease endLease(@PathVariable Long customerId, @PathVariable Long carId) {
        return customerService.endLease(customerId, carId);
    }

    @GetMapping("/{customerId}/leases")
    public List<Lease> getCustomerLeases(@PathVariable Long customerId) {
        return customerService.getCustomerLeases(customerId);
    }

}
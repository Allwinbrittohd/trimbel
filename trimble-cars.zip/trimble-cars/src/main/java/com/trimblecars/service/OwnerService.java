package com.trimblecars.service;

import com.trimblecars.model.*;
import com.trimblecars.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OwnerService {

    private final UserRepository userRepository;
    private final CarRepository carRepository;
    private final LeaseRepository leaseRepository;

    public User registerOwner(User owner) {
        owner.setRole(Role.OWNER);
        return userRepository.save(owner);
    }

    public Car addCar(Long ownerId, Car car) {
        User owner = userRepository.findById(ownerId)
                .orElseThrow(() -> new RuntimeException("Owner not found"));
        car.setOwner(owner);
        car.setStatus(CarStatus.IDLE);
        return carRepository.save(car);
    }

    public List<Car> getOwnerCars(Long ownerId) {
        User owner = userRepository.findById(ownerId)
                .orElseThrow(() -> new RuntimeException("Owner not found"));
        return carRepository.findByOwner(owner);
    }

    public List<Lease> getLeaseHistory(Long ownerId) {
        User owner = userRepository.findById(ownerId)
                .orElseThrow(() -> new RuntimeException("Owner not found"));
        return leaseRepository.findByCarOwner(owner);
    }
}

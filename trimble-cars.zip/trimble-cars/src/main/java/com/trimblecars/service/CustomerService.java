package com.trimblecars.service;

import com.trimblecars.model.*;
import com.trimblecars.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

    private final UserRepository userRepository;
    private final CarRepository carRepository;
    private final LeaseRepository leaseRepository;

    public User registerCustomer(User customer) {
        customer.setRole(Role.CUSTOMER);
        return userRepository.save(customer);
    }

    public List<Car> getAvailableCars() {
        return carRepository.findByStatus(CarStatus.IDLE);
    }

    public Lease startLease(Long customerId, Long carId) {
        User customer = userRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        long activeLeases = leaseRepository.countByCustomerAndEndDateIsNull(customer);
        if (activeLeases >= 2) {
            throw new RuntimeException("Customer has already leased 2 cars.");
        }

        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new RuntimeException("Car not found"));
        if (car.getStatus() != CarStatus.IDLE) {
            throw new RuntimeException("Car is not available for lease.");
        }

        car.setStatus(CarStatus.ON_LEASE);
        carRepository.save(car);

        Lease lease = Lease.builder()
                .car(car)
                .customer(customer)
                .startDate(LocalDate.now())
                .build();
        return leaseRepository.save(lease);
    }

    public Lease endLease(Long customerId, Long carId) {
        User customer = userRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        Car car = carRepository.findById(carId)
                .orElseThrow(() -> new RuntimeException("Car not found"));

        Lease lease = leaseRepository.findByCustomerAndCarAndEndDateIsNull(customer, car);
        if (lease == null) {
            throw new RuntimeException("Active lease not found.");
        }

        lease.setEndDate(LocalDate.now());
        leaseRepository.save(lease);

        car.setStatus(CarStatus.IDLE);
        carRepository.save(car);

        return lease;
    }

    // 🔁 Renamed this method
    public List<Lease> getCustomerLeases(Long customerId) {
        User customer = userRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return leaseRepository.findByCustomer(customer);
    }
}

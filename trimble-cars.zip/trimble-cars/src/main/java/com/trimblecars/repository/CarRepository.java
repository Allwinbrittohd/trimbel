package com.trimblecars.repository;

import com.trimblecars.model.Car;
import com.trimblecars.model.CarStatus;
import com.trimblecars.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByOwner(User owner);
    List<Car> findByStatus(CarStatus status);
}

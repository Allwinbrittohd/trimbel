package com.trimblecars.model;

public enum CarStatus {
    IDLE,
    ON_LEASE,
    ON_SERVICE
}

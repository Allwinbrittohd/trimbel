package com.trimblecars.model;

public enum Role {
    OWNER,
    CUSTOMER,
    ADMIN
}